//
//  ViewController.m
//  FirstApp
//
//  Created by INTAEK HAN on 2021/05/02.
//

#import "ViewController.h"
#import "Rectangle.h"

@interface ViewController () {
    
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
        
}

@end
